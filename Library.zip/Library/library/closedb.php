<?php
mysql_close($database);
?>