 <!-- Main Footer -->
    <footer class="main-footer">
      <!-- To the right -->
      <div class="pull-right hidden-xs">
        version 1.0.0
      </div>
      <!-- Default to the left -->
      <strong>Copyright &copy; 2017 <a href="#">Enfanto</a>.</strong> All rights reserved.
    </footer>