<?php
function GetLogInData($conn,$User_Name, $User_Password)
{
	$sql="SELECT * FROM tbl_user WHERE User_Name='$User_Name' AND User_Password='$User_Password'";
	return mysqli_query($conn,$sql);
}
function GetUserDataByUser($conn)
{
	$sql="SELECT * FROM tbl_user order by User_ID desc";
	return mysqli_query($conn,$sql);
}
function GetUserDataBy_UserName($conn,$User_Name)
{
	$sql="SELECT * FROM tbl_user WHERE User_Name='$User_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function InsertUser($conn,$User_ID, $User_Name,  $User_Password,$User_Type)
{
	$sql="INSERT INTO tbl_user(User_ID, User_Name,User_Password,User_Type) 
			VALUES('$User_ID', '$User_Name','$User_Password', '$User_Type')";
	mysqli_query($conn,$sql);
}
function UpdateUser($conn,$User_ID, $User_Name,  $User_Password,$User_Type)
{
	$sql="UPDATE tbl_user SET User_Name='$User_Name', 
							  User_Password='$User_Password',
							  User_Type='$User_Type'
							 
							WHERE User_ID='$User_ID'";
	mysqli_query($conn,$sql);
}
function DeleteUser($conn,$User_ID, $User_Name,  $User_Password,$User_Type)
{
	$sql="DELETE FROM tbl_user WHERE User_ID='$User_ID'";
	mysqli_query($conn,$sql);
}
?>