<?php
function GetMemberDataByMember($conn)
{
	$sql="SELECT * FROM tbl_member order by Member_ID asc";
	return mysqli_query($conn,$sql);
}
function GetMemberDataBy_MemberName($conn,$Member_Name)
{
	$sql="SELECT * FROM tbl_member WHERE Member_Name='$Member_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function InsertMember($conn,$Member_ID, $Member_Name, $Member_Phone, $Member_Email,$Member_Address,$Member_Blood,$Created_Date)
{
	$sql="INSERT INTO tbl_member(Member_ID, Member_Name, Member_Phone, Member_Email,Member_Address,Member_Blood,Created_Date) 
			VALUES('$Member_ID', '$Member_Name', '$Member_Phone','$Member_Email', '$Member_Address','$Member_Blood','$Created_Date')";
	mysqli_query($conn,$sql);
}
function UpdateMember($conn,$Member_ID, $Member_Name, $Member_Phone, $Member_Email,$Member_Address,$Member_Blood,$Created_Date)
{
	$sql="UPDATE tbl_member SET Member_Name='$Member_Name', 
							  Member_Phone='$Member_Phone',
							  Member_Email='$Member_Email', 
							  Member_Address='$Member_Address',
							  Member_Blood='Member_Blood',
							  Created_Date='Created_Date'
							 
							WHERE Member_ID='$Member_ID'";
	mysqli_query($conn,$sql);
}
function DeleteUser($conn,$Member_ID, $User_Name, $User_Role, $User_Email, $User_Password,$Created_Date,$Lastin_Date)
{
	$sql="DELETE FROM tbl_member WHERE Member_ID='$Member_ID'";
	mysqli_query($conn,$sql);
}
?>