<?php
include("../library/db.php");
class pager
{
	public $pageSize,$currentPageIndex;
	public $offset,$maxPage;
	public $totalRecordCount;
	
	//Constructor
	function __construct($pageSize,$currentPageIndex)
	{
		//Page Size
		$this->pageSize=$pageSize;
		//by default we show first page
		$this->currentPageIndex=$currentPageIndex;		
		//counting the offset
		$this->offset=($currentPageIndex-1)*$pageSize;
	}	

/////////////////////////// All AddressBook///////////////////////////
	
	function SearchData_GetAllUser($conn)
	{
		$sql="SELECT * FROM `tbl_user` ORDER BY User_ID DESC ";
		
		return $sql;
		
	}
	
	/////////////////////////// All Car ///////////////////////////
	/////////////////////////// Delivery Search Start ///////////////////////////*/
	
	function SearchData_UserSearch($conn,$User_Name, $User_Role)
	{
		$N="";
		$R="";
			
		$OrderBy=" ORDER BY User_ID";
		
		if($User_Name!="")
		{
			$N="User_Name LIKE '%$User_Name%' ";
		}
	
		
		
		if($User_Role!="")
			{
				if($N!="" )
				{
					$R=" AND User_Role LIKE '%$User_Role%'  ";
				}
				elseif($N=="")
				{
					$R=" User_Role LIKE '%$User_Role%'  ";
				}
			}
		
		
		$sql="SELECT * FROM `tbl_user` WHERE $N $R ";
		return $sql;
	}
	
	//function Search_Data($tableName,$orderByFieldName)

	function Search_Data($conn,$str)
	{
		
		$sql= $str . " LIMIT $this->offset,$this->pageSize";
		$this->totalRecordCount=$this->Search_TotalRecordCount($conn,$str);
		//how many pages
		$this->maxPage=ceil($this->totalRecordCount/$this->pageSize);	
		$result=mysqli_query($conn,$sql) ;
		return $result;
	}

	/********************************************************************/	

	function Search_TotalRecordCount($conn,$sql)
	{
		//If no search key is defined
		$ret=mysqli_query($conn,$sql);
		$num=mysqli_num_rows($ret);
		return $num;					
	}

	/********************************************************************/

	function Generate_Pager($str,$conn)
	{
		/********************************************************************/
		// creating previous and next link
		// plus the link to go straight to
		// the first and last page
		/********************************************************************/				
		
		//the name of the current page	
		$self = $_SERVER['PHP_SELF'];
		
		
		
		
		
		
		
		if(isset($_GET['btnSearch']) )
	{
	
		if ($this->currentPageIndex>1)
		{
			$pageIndex=$this->currentPageIndex-1;	
			?> <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php				
			echo "<a href='../User/AllUserPager?User_Name=".$_GET[User_Name]."&User_Role=".$_GET[User_Role]."&btnSearch=Search&page=1&$str'><<</a>&nbsp;";
			?></span>
             <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php		
			echo "<a href='../User/AllUserPager?User_Name=".$_GET[User_Name]."&User_Role=".$_GET[User_Role]."&btnSearch=Search&page=$pageIndex&$str'><</a>&nbsp;";
			?></span><?php							
		}

		else

		{}	
		
						

		/********************************************************************/
		// print the link to access each page

		$b=false;

		for($i=1;$i<=$this->maxPage;$i++)
		{
			if ($i==$this->currentPageIndex)
			{
				?><span style="background:#ec5d91; padding:5px 10px; border:2px solid#ccc; border-radius:2px; color:#ffffff;"><?php	
				echo $i . "&nbsp;";
				?></span><?php
			}

			else
			{
				
			}
		}

		/********************************************************************/

		// "Next" and "Last" page link
		if ($this->currentPageIndex<$this->maxPage)
		{
			$pageIndex=$this->currentPageIndex+1;
			?> <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php
			echo "<a href='../User/AllUserPager?User_Name=".$_GET[User_Name]."&User_Role=".$_GET[User_Role]."&btnSearch=Search&page=$pageIndex&$str'>></a>&nbsp;";?></span>
             <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php
			echo "<a href='../User/AllUserPager?User_Name=".$_GET[User_Name]."&User_Role=".$_GET[User_Role]."&btnSearch=Search&page=$this->maxPage&$str'>>></a>&nbsp;";?></span><?php
			echo " of total Page" . $this->maxPage;
		}

		else

		{}

		/********************************************************************/

	}
		
		
		
		
		/********************************************************************/
		// "Previous" and "First" page link
		if(!isset($_GET['btnSearch']) )
		{
	
			if ($this->currentPageIndex>1)
			{
				$pageIndex=$this->currentPageIndex-1;
				?> <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php					
				echo "<a href='../User/AllUserPager?page=1&$str'><<</a>&nbsp;";?></span>
                <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff;"><?php
				echo "<a href='../User/AllUserPager?page=$pageIndex&$str'><</a>&nbsp;";?></span><?php							
			}
	
			else
	
			{}								

		/********************************************************************/
		// print the link to access each page

		$b=false;

		for($i=1;$i<=$this->maxPage;$i++)
		{
			if ($i==$this->currentPageIndex)
			{
			?><span style="background:#ec5d91; padding:5px 10px; border:2px solid#ccc; border-radius:2px; color:#ffffff;"><?php	
					echo $i . "&nbsp;"; ?>
                </span>
                <?php
			}

			else
			{
				
			}
		}

		/********************************************************************/

		// "Next" and "Last" page link
		if ($this->currentPageIndex<$this->maxPage)
		{
			$pageIndex=$this->currentPageIndex+1;
			?> <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php
			echo "<a href='../User/AllUserPager?page=$pageIndex&$str'>></a>&nbsp;";?></span><?php
			?> <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff;"><?php
			echo "<a href='../User/AllUserPager?page=$this->maxPage&$str'>>></a>&nbsp;";?></span><?php
			echo " of total Page" . $this->maxPage;
		}

		else

		{}

		/********************************************************************/

	}//if
	
	}
	/********************************************************************/
	
	

}	

?>