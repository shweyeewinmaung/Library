-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2017 at 12:17 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `librarydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `Member_ID` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Member_Name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Member_Phone` int(20) NOT NULL,
  `Member_Email` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Member_Address` text COLLATE utf8_unicode_ci NOT NULL,
  `Member_Blood` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Created_Date` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`Member_ID`, `Member_Name`, `Member_Phone`, `Member_Email`, `Member_Address`, `Member_Blood`, `Created_Date`) VALUES
('M-000001', 'aa', 0, 'aa@gmail.com', '', '', 'adfa'),
('M-000002', 'gg', 555, 'aa@gmail.com', '555', '', 'aaa'),
('M-000003', 'bvdsav', 333, 'aa@gmail.com', '', 'A', 'aaa'),
('M-000004', 'tt', 44444, 'aa@gmail.com', 'vdasdv', 'A', 'aaa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `User_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `User_Name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `User_Password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `User_Type` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`User_ID`, `User_Name`, `User_Password`, `User_Type`) VALUES
('U-000001', 'aa', 'aa', 'Super Admin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
