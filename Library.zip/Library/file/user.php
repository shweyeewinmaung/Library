<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
//include("../library/permission.php");
include("../dal/dal_user.php");

$ret=GetUserDataByUser($conn);
$num=mysqli_num_rows($ret);
?>
<?php require_once("../template/sidebarfile.php");?>

     <!-- Content Wrapper. Contains page content -->
     <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1 style="color:#ec5d91;">
          Add User
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
          <li class="active">Add User</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content container-fluid">

        <div class="row">
          
         	<div class="container">
            <h1 class="page-header">User List</h1>
                  	<div class="table-responsive">
                      
                     <table id="user_data" class="table table-striped table-bordered">  
                         <thead>
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Created Date</th>
                    <th>Lastin Update</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                 <?php  $u=1;
				  	while($row=mysqli_fetch_array($ret)){	?>  
                <tr>
                    <th><?php echo $u; ?></th>
                    <th><?php echo $row['User_Name']; ?></th>
                    <th><?php echo $row['User_Role']; ?></th>
                    <th><?php echo $row['User_Email']; ?></th>
                    <th><?php echo $row['User_Password']; ?></th>
                    <th><?php echo $row['Created_Date']; ?></th>
                    <th><?php echo $row['Lastin_Date']; ?></th>
                    <th><a href="UserUpdate.php?User_ID=<?php echo $row['User_ID']; ?>"><img src="../img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                    <th><a href="UserDelete.php?User_ID=<?php echo $row['User_ID']; ?>">
    <img src="../img/cross-script.png" width="20" height="20" /></a></th>
                </tr>
               <?php $u=$u+1;  } ?> 
                     </table> 
                </div>  


                </div><!------contaioner----->
        </div>
        <!-- /.row -->




      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php require_once("../template/footerfile.php");?>


  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED JS SCRIPTS -->

 <script src="../js1/jquery.min.js"></script>  
    <script src="../js1/jquery.dataTables.min.js"></script>  
    <script src="../js1/dataTables.bootstrap.min.js"></script>            
    
    <script src="../js/custom.js"></script>
    <script>  
 $(document).ready(function(){  
     
	  
	    $('#user_data').DataTable().columns().every( function () {
       
 
        $( 'input').on( 'keyup change', function () {
            if ( that.search() !== this.value ) {
                that
                    .search( this.value )
                    .draw();
            }
        } );
		  } );
		
	
 });  
 </script>
  <style>
  #user_data_wrapper{
	  width:98%;
  }
  #user_data_filter{
	  float:right;
  }
  </style>