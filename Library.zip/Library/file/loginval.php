<?php
session_start();
include("../library/db.php");
include("../library/globalfunction.php");
require_once("../dal/dal_user.php");


//if(isset($_SESSION['SESS']['User']['User_ID']))
//{
	//header("Location:Profile.php");
//}

$User_Name=Clean($conn,$_POST['User_Name']);
$User_Password=Clean($conn,$_POST['User_Password']);

$ret=GetLogInData($conn,$User_Name, $User_Password);
$num=mysqli_num_rows($ret);

if($num>0)
{
	$row=mysqli_fetch_array($ret);
	$_SESSION['SESS']['User']['User_ID']=$row['User_ID'];
	$_SESSION['SESS']['User']['User_Name']=$row['User_Name'];
	$_SESSION['SESS']['User']['User_Password']=$row['User_Password'];
	$_SESSION['SESS']['User']['User_Type']=$row['User_Type'];
	
	header("location:../index.php");
}
else
{
	$_SESSION['LogIn']="Fail";
	header("location:LogIn.php");
}
?>