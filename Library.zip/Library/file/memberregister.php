<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
//include("../library/permission.php");
include("../dal/dal_member.php");

if (isset($_POST['Member_Name']))
{	
	$Member_ID=AutoID($conn, 'tbl_member','Member_ID','M-',6);
	$Member_Name=Clean($conn,$_POST['Member_Name']);
	$Member_Phone=Clean($conn,$_POST['Member_Phone']);
	$Member_Email=Clean($conn,$_POST['Member_Email']);
	$Member_Address=Clean($conn,$_POST['Member_Address']);
	$Member_Blood=Clean($conn,$_POST['Member_Blood']);
	$Created_Date=Clean($conn,$_POST['Created_Date']);
	
	
	
	$ret=GetMemberDataBy_MemberName($conn,$Member_Name);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['Member_Name']="Exist";
	}else{
		InsertMember($conn,$Member_ID, $Member_Name, $Member_Phone, $Member_Email,$Member_Address,$Member_Blood,$Created_Date);
		$_SESSION['Member_Name']="Success";
	}
}
?>
<?php require_once("../template/sidebarfile.php");?>

     <!-- Content Wrapper. Contains page content -->
     <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1 style="color:#ec5d91;">
          Add User
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
          <li class="active">Add User</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content container-fluid">

        <div class="row">
          
         	<div class="container">
                  	<form method="post">
                    		
                           <font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['Member_Name']=="Success"){ echo "Name is Added"; unset($_SESSION['Member_Name']);}
                             ?>
                            <?php 
                                if(@$_SESSION['Member_Name']=="Exist"){ echo "Already Exist!"; unset($_SESSION['Member_Name']);}
                            ?></font>
                            <div class="form-group">
                              <label for="Member_Name">Name:</label>
                              <input type="text" class="form-control" id="Member_Name" name="Member_Name">
                            </div>
                           <div class="form-group">
                              <label for="Member_Phone">Phone:</label>
                              <input type="text" class="form-control" id="Member_Phone" name="Member_Phone">
                            </div>
                           <div class="form-group">
                              <label for="Member_Email">Email:</label>
                              <input type="email" class="form-control" id="Member_Email" name="Member_Email">
                            </div>
                           
                           <div class="form-group">
                              <label for="User_Name">Address:</label>
                              <textarea name="Member_Address" rows="5"></textarea>
                             
                            </div>
                           
                           
                             <div class="form-group">
                            <label for="Member_Blood">Blood Type:</label>
                              <select class="form-control" id="Member_Blood" name="Member_Blood">
                                <option>A</option>
                                <option>B</option>
                               </select>
                              </div>
                              <div class="form-group">
                              <label for="Created_Date">Date:</label>
                               <input type="text" class="form-control" id="Created_Date" name="Created_Date">
                             
                            </div>
                             
                            <button type="submit" class="btn btn-default" name="btnAdd" >Entry</button>
                          
                          </form>
                </div><!------contaioner----->
        </div>
        <!-- /.row -->




      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php require_once("../template/footerfile.php");?>


  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED JS SCRIPTS -->

  