<?php
session_start();

?>
 <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../bower_components/Ionicons/css/ionicons.min.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">

  <link rel="stylesheet" href="../dist/css/skins/skin-purple.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">    <!-- Content Wrapper. Contains page content -->
     <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1 style="color:#ec5d91;">
          Add User
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
          <li class="active">Add User</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content container-fluid">

        <div class="row">
          
         	<div class="container">
                  	<form method="post" action="loginval.php">
                    		<?php
				if(isset($_SESSION['LogIn']) && $_SESSION['LogIn']="Fail")
				{
					?>
                    
	                    <th colspan="2" style="color:red; line-height:50px;"><b>Invalid LogIn! Please Try Again!!!</b></th>
                    <?php
				}
			?>
                            <div class="form-group">
                              <label for="User_Name">Name:</label>
                              <input type="text" class="form-control" id="User_Name" name="User_Name">
                            </div>
                           
                            <div class="form-group">
                              <label for="User_Password">Password:</label>
                              <input type="password" class="form-control" id="User_Password" name="User_Password">
                            </div>
                                                         
                            <button type="submit" class="btn btn-default" name="btnAdd" >Entry</button>
                          
                          </form>
                </div><!------contaioner----->
        </div>
        <!-- /.row -->




      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

  


  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED JS SCRIPTS -->

  