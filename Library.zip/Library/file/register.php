<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
//include("../library/permission.php");
include("../dal/dal_user.php");

if (isset($_POST['User_Name']))
{	
	$User_ID=AutoID($conn, 'tbl_user','User_ID','U-',6);
	$User_Name=Clean($conn,$_POST['User_Name']);
	$User_Password=Clean($conn,$_POST['User_Password']);
	$User_Type=Clean($conn,$_POST['User_Type']);
	
	
	$ret=GetUserDataBy_UserName($conn,$User_Name);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['User_Name']="Exist";
	}else{
		InsertUser($conn,$User_ID, $User_Name,  $User_Password,$User_Type);
		$_SESSION['User_Name']="Success";
	}
}
?>
<?php require_once("../template/sidebarfile.php");?>

     <!-- Content Wrapper. Contains page content -->
     <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1 style="color:#ec5d91;">
          Add User
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
          <li class="active">Add User</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content container-fluid">

        <div class="row">
          
         	<div class="container">
                  	<form method="post">
                    		
                           <font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['User_Name']=="Success"){ echo "Name is Added"; unset($_SESSION['User_Name']);}
                             ?>
                            <?php 
                                if(@$_SESSION['User_Name']=="Exist"){ echo "Already Exist!"; unset($_SESSION['User_Name']);}
                            ?></font>
                            <div class="form-group">
                              <label for="User_Name">Name:</label>
                              <input type="text" class="form-control" id="User_Name" name="User_Name">
                            </div>
                           
                            <div class="form-group">
                              <label for="User_Password">Password:</label>
                              <input type="password" class="form-control" id="User_Password" name="User_Password">
                            </div>
                             <div class="form-group">
                            <label for="User_Type">Type:</label>
                              <select class="form-control" id="User_Type" name="User_Type">
                                <option>Super Admin</option>
                                <option>Admin</option>
                               </select>
                              </div>
                             
                            <button type="submit" class="btn btn-default" name="btnAdd" >Entry</button>
                          
                          </form>
                </div><!------contaioner----->
        </div>
        <!-- /.row -->




      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php require_once("../template/footerfile.php");?>


  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED JS SCRIPTS -->

  